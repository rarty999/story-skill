---
name: story-test-upload-check
description: "Upload test only - verifying skill upload works for this account."
---

# Test

This is a minimal upload test.
